import {Zone} from "../zone/Zone"

export class Leviathan {
    private static _leviathan: Leviathan;

    private zones : Zone[];

    private constructor() {
        for (const roomName in Game.rooms) {
            const zone = new Zone(Game.rooms[roomName]);
            this.zones.push(zone);
        }
    }
    
    public static goToWar(): Leviathan {
        if (this._leviathan == null) {
            return new Leviathan();
        } else {
            return this._leviathan;
        }
    }

    public init() {
        for (const zone of this.zones) {
            zone.init();
        }
    }

    public publishRequire() {
        for (const zone of this.zones) {
            zone.publishRequire();
        }
    }

    public acceptRequire() {
        for (const zone of this.zones) {
            zone.acceptRequire();
        }
    }

    public runTasks() {
        for (const zone of this.zones) {
            zone.runTasks();
        }
    }
}