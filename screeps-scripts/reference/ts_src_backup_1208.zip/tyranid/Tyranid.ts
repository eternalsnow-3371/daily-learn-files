import { CREEP_BEHAVIOR_RANGES } from "../common/CreepConstants";

export class Tyranid {
    creep: Creep;
    memory: CreepMemory;
    role: string;

    constructor(creep: Creep) {
        this.creep = creep;
        this.memory = creep.memory;
        this.role = creep.memory.role;
    }

    goHarvest(target: Source | Mineral) {
        if (this.creep.pos.inRangeToPos(target.pos, CREEP_BEHAVIOR_RANGES.HARVEST)) {
            return this.creep.harvest(target);
        } else {
            return this.creep.moveTo(target);
        }
    }

    goTransfer(target: Structure, resourceType: ResourceConstant = RESOURCE_ENERGY, amount?: number) {
        if (this.creep.pos.inRangeToPos(target.pos, CREEP_BEHAVIOR_RANGES.TRANSFER)) {
            return this.creep.transfer(target, resourceType, amount);
        } else {
            return this.creep.moveTo(target);
        }
    }

    goBuild(target: ConstructionSite) {
        if (this.creep.pos.inRangeToPos(target.pos, CREEP_BEHAVIOR_RANGES.BUILD)) {
            return this.creep.build(target);
        } else {
            return this.creep.moveTo(target);
        }
    }

    goUpgradeController(target: StructureController) {
        if (this.creep.pos.inRangeToPos(target.pos, CREEP_BEHAVIOR_RANGES.UPGRADE_CONTROLLER)) {
            return this.creep.upgradeController(target);
        } else {
            return this.creep.moveTo(target);
        }
    }

    public init() {}

    public publishRequire() {}

    public acceptRequire() {}

    public runTasks() {}
}