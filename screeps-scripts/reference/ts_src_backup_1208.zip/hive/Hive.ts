import {Tyranid} from "../tyranid/Tyranid";

export class Hive {
    room: Room;
    memory: HiveMemory;

    roomName: string;

    tyranids: Tyranid[];

    controller: StructureController;

    constructionSites: ConstructionSite[];

    spawns: StructureSpawn[];
    extensions: StructureExtension[];
    towers: StructureTower[];
    
    sources: Source[];

    constructor(room: Room) {
        this.room = room;
        this.memory = room.memory;
        this.roomName = room.name;
        this.controller = room.controller!;
        this.constructionSites = room.constructionSites;
        this.spawns = room.spawns;
        this.extensions = room.extensions;
        this.towers = room.towers;
        this.sources = room.sources;
        this.tyranids = [];
        for (const creep of room.creeps) {
            this.tyranids.push(new Tyranid(creep));
        }
    }

    public init() {
        for (const tyranid of this.tyranids) {
            tyranid.init();
        }
    }

    public publishRequire() {
        for (const tyranid of this.tyranids) {
            tyranid.publishRequire();
        }
    }

    public acceptRequire() {
        for (const tyranid of this.tyranids) {
            tyranid.acceptRequire();
        }
    }

    public runTasks() {
        for (const tyranid of this.tyranids) {
            tyranid.runTasks();
        }
    }
}