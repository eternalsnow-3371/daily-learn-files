import './prototypes/RoomPosition';
import {Leviathan} from "./leviathan/Leviathan";

let _leviathan = Leviathan.goToWar();

function main(): void {
    _leviathan.init();
    _leviathan.publishRequire();
    _leviathan.acceptRequire();
    _leviathan.runTasks();
};

export const loop = main;