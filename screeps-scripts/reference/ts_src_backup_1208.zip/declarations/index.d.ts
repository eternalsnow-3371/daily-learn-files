interface RequireData {
	resourceType?: string;
	amount?: number;
}