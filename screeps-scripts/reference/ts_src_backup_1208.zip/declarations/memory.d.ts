interface RoomMemory {
}

interface HiveMemory {
}

interface CreepMemory {
	role: string;
}