interface RoomPosition {
    inRangeToPos(pos: RoomPosition, range: number): boolean;
}

interface Room {
    creeps: Creep[];

    constructionSites: ConstructionSite[];

    spawns: StructureSpawn[];
    extensions: StructureExtension[];
    towers: StructureTower[];
    
    sources: Source[];
}