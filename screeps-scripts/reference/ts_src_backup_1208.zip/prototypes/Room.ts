Object.defineProperty(Room.prototype, 'creeps', {
    get() {
        if (!this._creeps) {
            this._creeps = this.find(FIND_MY_CREEPS);
        }
        return this._creeps;
    },
    configurable: true,
});

Object.defineProperty(Room.prototype, 'constructionSites', {
    get() {
        if (!this._constructionSites) {
            this._constructionSites = this.find(FIND_MY_CONSTRUCTION_SITES);
        }
        return this._constructionSites;
    },
    configurable: true,
});

Object.defineProperty(Room.prototype, 'spawns', {
    get() {
        if (!this._spawns) {
            this._spawns = this.find(FIND_MY_SPAWNS);
        }
        return this._spawns;
    },
    configurable: true,
});

Object.defineProperty(Room.prototype, 'extensions', {
    get() {
        if (!this._extensions) {
            this._extensions = this.find(FIND_MY_STRUCTURES, {
                filter: (s: Structure) => s.structureType = STRUCTURE_EXTENSION
            });
        }
        return this._extensions;
    },
    configurable: true,
});

Object.defineProperty(Room.prototype, 'towers', {
    get() {
        if (!this._towers) {
            this._towers = this.find(FIND_MY_STRUCTURES, {
                filter: (s: Structure) => s.structureType = STRUCTURE_TOWER
            });
        }
        return this._towers;
    },
    configurable: true,
});

Object.defineProperty(Room.prototype, 'sources', {
    get() {
        if (!this._sources) {
            this._sources = this.find(FIND_SOURCES);
        }
        return this.find(FIND_SOURCES);
    },
    configurable: true,
});