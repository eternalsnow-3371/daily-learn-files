RoomPosition.prototype.inRangeToPos = function(pos: RoomPosition, range: number): boolean {
	return this.roomName === pos.roomName &&
		   ((pos.x - this.x) < 0 ? (this.x - pos.x) : (pos.x - this.x)) <= range &&
		   ((pos.y - this.y) < 0 ? (this.y - pos.y) : (pos.y - this.y)) <= range;
};