import { ResourceRequire } from "./instance/resource";

export type TaskType = ResourceRequire;

export abstract class Task {
    taskType: string;
    publisherRef: string;

    creepName: string;

    resourceType: ResourceConstant;
    amount: number | undefined;

    constructor(taskType: string, publisherRef: string, resourceType: ResourceConstant, amount?: number) {
        this.taskType = taskType;
        this.publisherRef = publisherRef;
        this.creepName = '';
        this.resourceType = resourceType;
        this.amount = amount;
    }

    get publisher(): RoomObject | null {
        const id: Id<RoomObject> = this.publisherRef as Id<RoomObject>;
        return Game.getObjectById(id);
    }

    get creep(): Creep {
        return Game.creeps[this.creepName];
    }

    set creep(creep: Creep) {
        this.creepName = creep?.name;
    }

    abstract run(): boolean;

}