import { Task } from "../Task";

export const resourceRequireType = 'resource';

export type resourceRequirePublisherType =
  StructureSpawn
  | StructureExtension
  | StructureTower
  | Creep;


export class ResourceRequire extends Task {
  constructor(publisher: resourceRequirePublisherType, resourceType: ResourceConstant, amount?: number) {
    super(resourceRequireType, publisher.id, resourceType, amount);
  }

  isValidTask() {
    let target = this.publisher as resourceRequirePublisherType;
    if (target instanceof Creep) {
      return target.store.getFreeCapacity() > 0;
    } else {
      return target.energyCapacity - target.energy > 0;
    }
  }

  run(): boolean {
    if (!this.creep) {
      return false;
    }
    if (this.resourceType == RESOURCE_ENERGY) {
      if (this.creep.store.getFreeCapacity() > 0) {
        const sources = this.creep.room.find(FIND_SOURCES);
        if (this.creep.harvest(sources[0]) === ERR_NOT_IN_RANGE) {
          this.creep.moveTo(sources[0]);
        }
      }
      else {
        let target = this.publisher as resourceRequirePublisherType;
        if (this.creep.transfer(target, RESOURCE_ENERGY) === ERR_NOT_IN_RANGE) {
          this.creep.moveTo(target);
        }
      }
    }
    return true;
  }
}

